set -x
java -jar ../vdmj-3.1.1.jar -vdmsl flat.def
java -jar ../vdmj-3.1.1.jar -vdmsl -q -w flat.def
java -jar ../vdmj-3.1.1.jar -vdmsl -w -e "f(10)" flat.def
java -jar ../vdmj-3.1.1.jar -vdmsl -e "f(10)" -q -w flat.def

echo Interactive test...
java -jar ../vdmj-3.1.1.jar -vdmsl -i -w flat.def

java -jar ../vdmj-3.1.1.jar -vdmsl -p -w flat.def
java -jar ../vdmj-3.1.1.jar -vdmsl -e "f(0)" -w flat.def
java -jar ../vdmj-3.1.1.jar -vdmsl -pre -e "f(0)" -w flat.def
java -jar ../vdmj-3.1.1.jar -vdmsl -w -o flat.lib flat.def
java -jar ../vdmj-3.1.1.jar -vdmsl flat.lib -e "f(10)"
