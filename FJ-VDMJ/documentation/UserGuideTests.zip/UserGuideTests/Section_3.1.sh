set -x
java -jar ../vdmj-2.0.1.jar -vdmpp -i CT2.vpp
