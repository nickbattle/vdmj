set -x
java -jar ../vdmj-3.1.1.jar -vdmsl -i -r vdm10 stdlib.vdm stdlib/MATH.vdm
