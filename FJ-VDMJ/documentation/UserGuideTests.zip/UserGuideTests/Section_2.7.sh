set -x
java -jar ../vdmj-2.0.1.jar -vdmsl -i -r vdm10 stdlib.vdm stdlib/MATH.vdm
