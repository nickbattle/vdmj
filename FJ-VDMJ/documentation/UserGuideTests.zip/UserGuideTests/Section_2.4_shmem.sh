set -x
java -jar ../vdmj-2.0.1.jar -vdmsl -i shmem.vdm
