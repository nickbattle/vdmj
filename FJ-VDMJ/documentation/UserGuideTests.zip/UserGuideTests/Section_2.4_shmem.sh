set -x
java -jar ../vdmj-3.1.1.jar -vdmsl -i shmem.vdm
