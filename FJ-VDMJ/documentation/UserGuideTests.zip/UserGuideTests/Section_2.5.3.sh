set -x
java -jar ../vdmjc-3.1.1.jar -vdmrt load vice.vpp
