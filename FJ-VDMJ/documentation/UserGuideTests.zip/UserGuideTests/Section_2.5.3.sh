set -x
java -jar ../vdmjc-2.0.1.jar -vdmrt load vice.vpp
