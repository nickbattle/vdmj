set -x
java -jar ../vdmj-3.1.1.jar -vdmpp -i threads.vpp stdlib/IO.vpp
