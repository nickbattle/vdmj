set -x
java -jar ../vdmj-3.1.1.jar -vdmpp -i test.vpp
