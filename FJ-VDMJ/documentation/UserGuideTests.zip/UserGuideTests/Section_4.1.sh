set -x
java -jar ../vdmj-3.1.1.jar -vdmpp -i CT2.vpp
