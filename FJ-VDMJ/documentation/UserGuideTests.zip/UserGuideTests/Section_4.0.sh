set -x
java -jar ../vdmj-3.1.1.jar -vdmpp -i CT1.vpp
